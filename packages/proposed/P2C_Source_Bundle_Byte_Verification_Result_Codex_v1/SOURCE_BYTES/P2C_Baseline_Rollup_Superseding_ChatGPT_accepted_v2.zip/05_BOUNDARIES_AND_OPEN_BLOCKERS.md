# Boundaries and Open Blockers

## Standing boundary block

```text
PROJECT-MODEL NUMBERS ONLY
NOT SERVER-TRUTH EXACT PROBABILITY
SOURCE/PROVENANCE BLOCKERS REMAIN OPEN
MML IS PROJECT-MODEL ASSUMPTION ONLY
PD-013 REMAINS OPEN
```

## Open blockers

- Source/provenance blockers remain open.
- MML remains a project-model assumption only.
- PD-013 remains open.
- Server-truth probability framing remains forbidden.
- Fractured-crit dependency and related source/tier issues are not closed by crit-family mapping.
- Lich remains out of scope; `lich_tag` must not be used as a mapping signature unless a future Lich gate explicitly opens and approves that domain.

## Out of scope unless separately gated

- Reveal mechanics.
- Lich mechanics.
- Abyssal mechanics.
- Whittling mechanics.
- Constructed two-add numeric output beyond accepted prior structural work.
- Optimizer, economics, EV, expected attempts, budget, route ranking, and crafting advice.

## Critical wording rules

Do not write or imply:

- official probability;
- true game probability;
- server-truth chance;
- best family;
- should aim for;
- optimal route;
- expected cost;
- EV-positive.

Use mechanical framing only: project-model evidence, internal classification, release excerpt, source-backed mapping, and accepted fingerprints.
