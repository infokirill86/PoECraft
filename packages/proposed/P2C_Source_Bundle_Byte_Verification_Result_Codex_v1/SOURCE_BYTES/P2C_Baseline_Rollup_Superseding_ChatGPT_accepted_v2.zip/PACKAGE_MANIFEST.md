# Package Manifest

```yaml
package_name: P2C_Baseline_Rollup_Superseding_ChatGPT_accepted_v2.zip
package_type: SUPERSEDING_BASELINE_ROLLUP / CURRENT_TRUTH_HANDOFF
status: accepted_by_user_go_and_chatgpt_synthesis
generation_date: 2026-07-05
language_surface: English-only artifacts; Russian only in ChatGPT/user conversation
numeric_probability_values_included: false
quarantined_artifacts_included: false
public_release_authorized_by_this_package: false
source_provenance_closed: false
mml_closed: false
pd_013_closed: false
server_truth_claim: false
supersedes_as_preferred_handoff:
  - P2C_Baseline_Rollup_ChatGPT_accepted_v1.zip
  - P2C_Baseline_Rollup_Delta_ChatGPT_accepted_v1_1.zip
  - P2C_Current_Truth_Rollup_Delta_M8C4_ChatGPT_accepted_v1.zip
base_rollup_sha: 2d30f6cf6dcaf045bd64d8902e28b44e99cabf418bd9861672633a7bc9d23c84
baseline_delta_v1_1_sha: 20ebfe60f492168423c959dcfe684a3be70863bc6255b10a326ac03408600b42
m8c4_current_truth_delta_sha: 345c27ffffbe1f65bc78dab9d745c46ba833cac74ce35fe168bfced1cf3ed65a
```

| File | Status | Include reason |
|---|---|---|
| 00_README_FIRST.md | new | Entry point and status. |
| 01_CURRENT_TRUTH_SUPERSEDING_BASELINE.md | new | Current accepted truth surface. |
| 02_ACCEPTED_GATES_AND_EVIDENCE.md | new | Gate/evidence summary. |
| 03_ACCEPTED_ARTIFACT_REGISTER.md | new | Artifact pins and roles. |
| 04_CLASSIFICATION_AND_RELEASE_STATE.md | new | M8C2/M8C3/M8C4 state and release limits. |
| 05_BOUNDARIES_AND_OPEN_BLOCKERS.md | new | Boundaries and open blockers. |
| 06_PROCESS_AND_PACKAGE_RULES.md | new | Process rules carried forward. |
| 07_NEXT_FLOOR_OPTIONS.md | new | Safe next directions. |
| PACKAGE_MANIFEST.md | new | Manifest and package metadata. |
| SHA256SUMS.txt | generated | Integrity hashes. |
