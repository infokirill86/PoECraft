# Current Truth - Superseding Baseline v2

Generation date: 2026-07-05.

## Current project position

The accepted current project state is:

```text
Candidate 1A ordinary non-Reveal single-add model:
- accepted internal numeric evidence exists;
- accepted full single-add mod surface exists;
- accepted source-backed family mapping exists;
- a full family aggregate excerpt has been audited and displayed as a labeled unit;
- public release remains limited to separately audited excerpt candidates.
```

## Core accepted facts

- M8C2 produced the first accepted quarantined numeric evidence for ordinary single-add.
- M8C3 produced the accepted full single-add mod surface classification.
- M8C4 produced the accepted source-backed family mapping over the full M8C3 surface.
- The M8C4 full family aggregate release candidate was audited and displayed with full labels/context.

## Current single-add surface status

```text
single_add_rows: 296
mode_counts:
  mml_off: 152
  mml_35: 83
  mml_50: 61
affix_side_rows:
  prefix: 141
  suffix: 155
family_mapping:
  classified: 296
  unmapped: 0
full_family_aggregate_units: 66
```

## Still forbidden

- No server-truth probability claim.
- No broad public release of full tables without a separate release gate.
- No optimizer, economics, EV, expected attempts, budget, ranking, route guidance, or crafting advice.
- No source/provenance closure.
- No MML closure.
- No PD-013 closure.
- No Reveal, Lich, Abyssal, Whittling expansion without separate gates.
