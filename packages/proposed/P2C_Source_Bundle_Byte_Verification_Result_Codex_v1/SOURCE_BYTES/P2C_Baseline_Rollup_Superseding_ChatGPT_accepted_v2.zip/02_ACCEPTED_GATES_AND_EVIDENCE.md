# Accepted Gates and Evidence Chain

## Process and baseline

| Gate / artifact | Status | Notes |
|---|---|---|
| Master Execution Architecture v2 | ACCEPTED PROCESS BASELINE | Baseline + delta + focused audit workflow adopted. |
| Baseline Rollup v1 | ACCEPTED | Previous preferred handoff baseline. |
| Baseline Rollup Delta v1.1 | ACCEPTED | Low-risk delta carrying full M4 candidate digest and lich_tag_priority wording. |
| Current Truth Rollup Delta M8C4 v1 | ACCEPTED | Captured M8C3, M8C4, and full family aggregate status before this superseding rollup. |

## M8C2 numeric evidence

| Gate / artifact | Status | Notes |
|---|---|---|
| Single-add quarantined numeric result | ACCEPTED INTERNAL EVIDENCE | Accepted as internally valid project-model numeric evidence. No public broad release. |

## M8C3 classification evidence

| Gate / artifact | Status | Notes |
|---|---|---|
| Full single-add mod surface result | ACCEPTED INTERNAL EVIDENCE | All accepted rows preserved; tier and affix_side classified; affix_side resolved from real StaticModifier.side. |

## M8C4 mapping evidence

| Gate / artifact | Status | Notes |
|---|---|---|
| Source-backed family mapping result | ACCEPTED INTERNAL EVIDENCE | All rows classified; family_key source-backed by StaticModifier.family_id where newly mapped. |

## Release excerpts

| Excerpt | Status | Notes |
|---|---|---|
| Shape A single row | DISPLAYED | Single audited mechanical sample only. |
| Shape B project-family filtered group | DISPLAYED | Audited filtered slice, not top-N or advice. |
| Family aggregate over Shape B | DISPLAYED | Audited aggregate over the Shape B slice. |
| Full family aggregate over M8C4 | DISPLAYED | Audited full partition aggregate over all accepted mapped rows. |
