# Process and Package Rules

## Default workflow

Plan big. Implement medium. Audit focused. Merge only accepted.

Ordinary work proceeds through pinned DELTAs against this baseline, not full historical dumps.

## Package hygiene

- Ordinary DELTA target: below 500 KB.
- Any package above 1 MB requires a size budget report.
- No nested old ZIP packages in ordinary work.
- No unchanged accepted documents embedded unless needed as evidence.
- Every package declares package type, baseline pins, file status, and include reason.
- Every DELTA must pin its base baseline SHA and prior-delta chain when stacked.

## Agent roles

- ChatGPT: project controller, continuity keeper, synthesis, acceptance record.
- Codex: implementer, scaffolder, package producer.
- Claude: external auditor and gate reviewer.

## Acceptance rule

No agent or package self-accepts. Accepted truth or milestone closure requires ChatGPT/User synthesis and approval.

## Release rule

Internal/quarantined evidence is not public release. Any value display requires a separate release excerpt candidate, Claude audit, and ChatGPT/User approval.
