# Accepted Artifact Register

| Artifact | SHA256 | Status | Role |
|---|---|---|---|
| P2C_Master_Execution_Architecture_Blueprint_Codex_v2.zip | 094632983a72b7588252f9538998cc6a4e2d7cd26ed3f63b6b259d7ade66e175 | ACCEPTED | Process baseline. |
| P2C_Baseline_Rollup_ChatGPT_accepted_v1.zip | 2d30f6cf6dcaf045bd64d8902e28b44e99cabf418bd9861672633a7bc9d23c84 | SUPERSEDED BY THIS ROLLUP | Prior preferred handoff baseline. |
| P2C_Baseline_Rollup_Delta_ChatGPT_accepted_v1_1.zip | 20ebfe60f492168423c959dcfe684a3be70863bc6255b10a326ac03408600b42 | FOLDED INTO THIS ROLLUP | Low-risk baseline delta; ChatGPT/User-provided lineage pin. |
| P2C_Current_Truth_Rollup_Delta_M8C4_ChatGPT_accepted_v1.zip | 345c27ffffbe1f65bc78dab9d745c46ba833cac74ce35fe168bfced1cf3ed65a | FOLDED INTO THIS ROLLUP | Post-M8C4 current truth delta. |
| P2C_M8C2_Single_Add_Quarantined_Numeric_Result_Codex_v1.zip | aaf8ac5c7ac84fb871acac2d5b42096944afbb295c0b972dd7798dc0c3ebaa1c | ACCEPTED INTERNAL EVIDENCE | Quarantined numeric result. |
| P2C_M8C3_Full_Single_Add_Mod_Surface_Result_Codex_v1.zip | 91e5eed3849bc4476cb164dfdf5ca16b10101d4a74c5ff655afba042ef490b0f | ACCEPTED INTERNAL EVIDENCE | Full single-add mod surface classification. |
| P2C_M8C4_Source_Backed_Family_Mapping_Result_Codex_v1.zip | c54daacc0de4eab67b6fd476e734c204ab715e5b737f8bac6fcc005182b1379c | ACCEPTED INTERNAL EVIDENCE | Source-backed family mapping result. |
| P2C_Release_Excerpt_Candidate_FullFamilyAggregate_M8C4_Codex_v1.zip | 4000806a2359f1628390bc81b2588072bbd077c36c0c808cc2b2176c82c3bb16 | DISPLAYED EXCERPT | Full family aggregate over M8C4 mapped surface. |
