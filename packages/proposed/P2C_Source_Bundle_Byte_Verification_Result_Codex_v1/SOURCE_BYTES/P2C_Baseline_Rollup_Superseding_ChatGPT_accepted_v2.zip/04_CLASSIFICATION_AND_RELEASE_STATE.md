# Classification and Release State

## Internal evidence state

The internal single-add model surface is now structurally complete for Candidate 1A ordinary non-Reveal single-add:

```text
rows: 296
mode_count_mml_off: 152
mode_count_mml_35: 83
mode_count_mml_50: 61
family_classified_rows: 296
family_unmapped_rows: 0
affix_side_prefix_rows: 141
affix_side_suffix_rows: 155
full_family_aggregate_units_displayed: 66
```

## Provenance of classification fields

- Probability fields are carried from the accepted M8C2 quarantined numeric result.
- Tier is extracted deterministically from accepted row identifiers/mod identifiers.
- Affix side is resolved from real `StaticModifier.side` under accepted fingerprints.
- Newly mapped family keys are source-backed by real `StaticModifier.family_id` under accepted fingerprints.
- Preexisting M8C3 family mappings remain preserved with honest provenance.

## Release state

Displayed excerpts are not broad release permissions. They authorize only the exact audited units already shown.

A new public display still requires:

1. release excerpt candidate;
2. ChatGPT pre-check;
3. Claude audit GO;
4. explicit ChatGPT/User display approval.

Standing labels for every released unit:

```text
PROJECT-MODEL NUMBERS ONLY
NOT SERVER-TRUTH EXACT PROBABILITY
SOURCE/PROVENANCE BLOCKERS REMAIN OPEN
MML IS PROJECT-MODEL ASSUMPTION ONLY
PD-013 REMAINS OPEN
```
