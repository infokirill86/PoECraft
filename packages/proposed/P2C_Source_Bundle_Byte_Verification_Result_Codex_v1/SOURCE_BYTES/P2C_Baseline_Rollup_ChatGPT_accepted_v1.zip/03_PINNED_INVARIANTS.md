# Pinned Invariants

These invariants must be carried into future DELTAs and audits when relevant.

| Name | Value | Status | Use |
|---|---|---|---|
| post-M7h semantic fingerprint | `b268eb88389461d6cf5a435050278caaf0f36b3acfbf74e4bf1d29f9d2e14c3a` | ACCEPTED carry-forward | Static semantic continuity check. |
| accepted source-data fingerprint | `1577c05b13f02611d08111a5db7a765de61a30793c1b864840d6e5831efbf05b` | ACCEPTED carry-forward | Real-data snapshot continuity check. |
| initial-state hash | `6f50bd3a650f615821750eef8b8de8f1b18d63b8e024dda1091abb4009806b32` | ACCEPTED carry-forward | Fractured Crit Quarterstaff initial-state identity. |
| M4 compact hash | `a155c13eda6b979292bd03d339ac0cc5f49645aa3bbf008b7c054dcc4f24e294` | ACCEPTED carry-forward | Compact M4 ledger continuity. |
| M4 full hash | `a55fa602b408e788baf7908e9cfada01ec5e1f6d5bac80790f866cb74330910e` | ACCEPTED carry-forward | Full M4 ledger continuity. |
| M4 validator evidence hash prefix | `8d289dcf...` | KNOWN PREFIX ONLY in this rollup | Mentioned in prior audit evidence; exact full value should be recovered if needed. |
| static index | `188` | ACCEPTED carry-forward | Static index continuity check. |
| old foundation fingerprint retained | `82fe2cfd20cee78f794c6b2df9dc2afd20b9709e17c83c309bdfee1a5fd8547f` | LEGACY RETAINED | Historical carry-forward reference. |

## Invariant handling rule

Any future numeric or real-data DELTA that changes one of these values must STOP unless the change is explicitly acknowledged, justified, and audited.
