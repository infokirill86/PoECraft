# Procedural Incidents Register

These incidents are not project regressions, but they are preserved for chain-of-custody clarity.

| Incident | Status | Lesson |
|---|---|---|
| Initial floor-start v1 package was large due to recursive nested historical ZIPs. | Resolved by F0 and compact v2. | Ordinary review packages must not embed old packages. |
| Claude RC verification initially received a package byte-identical to v2 instead of actual v3. | Resolved by uploading real v3; Claude then gave GO. | Verify SHA before assuming file identity. |
| Claude result audit request initially arrived without the result ZIP. | Resolved by uploading actual result ZIP; Claude then audited successfully. | Audit cannot proceed from summaries alone. |

## Standing chain-of-custody rule

No verification claim is accepted unless the verifying agent had the actual artifact bytes and a pinned SHA or deterministic reconstruction path.
