# Boundaries and Source Pointers

## Standing boundary block

PROJECT-MODEL NUMBERS ONLY
NOT SERVER-TRUTH EXACT PROBABILITY
SOURCE/PROVENANCE BLOCKERS REMAIN OPEN
MML IS PROJECT-MODEL ASSUMPTION ONLY
PD-013 REMAINS OPEN

## Source/provenance status

Headline status: source/provenance blockers remain open.

Detailed source status pointer: M8A provenance manifest and coverage matrix, including blocker rows D-001 through D-008.

Known navigation notes:

- Missing or unembedded original PoE2DB and Craft of Exile artifacts remain part of source/provenance blocker tracking.
- Fractured-Crit tier status remains a specific source/provenance dependency to keep visible.
- PoE2DB and Craft of Exile agreement remains project-model corroboration only, not independent server-truth proof.
- Cross-version source mismatch remains a stop trigger.

## MML

MML remains a project-model assumption only. It is not closed as server-truth behavior.

## PD-013

PD-013 remains open. Any Lich-related floor must treat PD-013 prerequisite status explicitly before proceeding.

## Excluded mechanics

Reveal, Lich, Abyssal, and Whittling remain outside Candidate 1A unless separately gated.

## Optimizer and economics

Optimizer, economics, expected attempts, costs, budgets, EV, and ranked routes remain out of scope until later gates.
