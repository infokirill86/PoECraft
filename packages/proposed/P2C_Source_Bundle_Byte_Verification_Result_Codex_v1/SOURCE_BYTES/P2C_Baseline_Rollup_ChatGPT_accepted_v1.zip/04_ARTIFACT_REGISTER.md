# Artifact Register

This register records key artifacts by status. It is reference-only and does not embed numeric artifacts.

| Artifact | Size bytes | SHA256 | Status | Notes |
|---|---:|---|---|---|
| `P2C_Master_Execution_Architecture_Blueprint_Codex_v2.zip` | 10351 | `094632983a72b7588252f9538998cc6a4e2d7cd26ed3f63b6b259d7ade66e175` | ACCEPTED PROCESS BASELINE | Reference pin. |
| `P2C_F1_Current_Truth_Capsule_ChatGPT_accepted_v1.zip` | 6345 | `3455aafd8546accbd00501bf0320e0c17d4faee0b28ce292d595213b580d3cf8` | ACCEPTED CURRENT TRUTH CAPSULE | Reference pin. |
| `P2C_F1_Current_Truth_Capsule_Spot_Audit_Claude_v1.md` | 6876 | `e3918c8c13e76667a1d4bacf87805cd987baa72dc954e8d9b6f0feb4bf4ad274` | CLAUDE SPOT AUDIT | Reference pin. |
| `P2C_M8C2_Single_Add_Quarantined_Numeric_Result_Codex_v1.zip` | 21877 | `aaf8ac5c7ac84fb871acac2d5b42096944afbb295c0b972dd7798dc0c3ebaa1c` | ACCEPTED INTERNAL NUMERIC EVIDENCE, VALUES QUARANTINED | Do not use as public release artifact. |
| `P2C_M8C2_Single_Add_Quarantined_Numeric_Result_Audit_Claude_v1.md` | 8364 | `ef878af5a17504f271eb1418accb22aed0002ad707505319096287eecfdb35e9` | CLAUDE RESULT AUDIT GO | Reference pin. |
| `P2C_M8C2_Single_Add_Quarantined_Numeric_Floor_Start_Package_Codex_v3.zip` | 11506 | `245741c6fa6dc06a3be1449e01921b22b6a2dcfbb1519ec370ee2250d2d23624` | ACCEPTED FLOOR-START BASIS | Reference pin. |
| `P2C_M8C2_Single_Add_Numeric_Floor_Start_v3_RC1_Verification_Claude_v1.md` | 5780 | `8baf636bde616d4c09b145a04226f7f7d9695ba0f321684c8ecd30d27293451b` | CLAUDE RC-1 GO | Reference pin. |
| `P2C_M8C2_Single_Add_Quarantined_Numeric_Floor_Start_Package_Codex_v2.zip` | 24810 | `3b6f0d2303d776794aa4052151850d29a890d33ecccee89f47fd1986154a57de` | SUPERSEDED BY V3 | Reference pin. |
| `P2C_M8C2_Single_Add_Numeric_Floor_Start_v2_Audit_Claude_v1.md` | 7777 | `7b05f5009953671c0dc23d452261084f81c375a4c4309df47279d3714a7c28fa` | CLAUDE AUDIT GO WITH CHANGES | Reference pin. |
| `P2C_F0_Bloat_Audit_ChatGPT_v1.zip` | 6284 | `050cd7b6ae3dbfb5309cdcfb3eb33f5e8d12db93b0e6b58747a08a9ab0cc2513` | F0 BLOAT AUDIT | Reference pin. |
| `P2C_M8C2_Single_Add_Quarantined_Numeric_Floor_Start_Package_Codex_v1.zip` | 12820419 | `a6a4cbd190a1fc616f410523d85d42758fef74161f713d863e39b419f30bec69` | FULL_REPRO_HISTORY CANDIDATE, NOT ORDINARY DELTA | Recursive historical ZIP bloat source; superseded for ordinary review. |
| `P2C_M8C2_Single_Add_Numeric_Result_Audit_BLOCKED_Claude_v1.md` | 3132 | `not_recomputed_in_register_optional_note` | BLOCKED PROCEDURAL NOTE | Keep visible as chain-of-custody incident. |
