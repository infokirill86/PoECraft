# Package Manifest

package_name: P2C_Baseline_Rollup_ChatGPT_accepted_v1.zip
package_type: BASELINE_ROLLUP / CURRENT_TRUTH_SUPERSET
status: accepted_by_chatgpt_after_user_go
created_date: 2026-07-05
numeric_probability_values_included: no
quarantined_numeric_artifacts_included: no
public_numeric_release_authorized: no
supersedes_for_handoff: P2C_F1_Current_Truth_Capsule_ChatGPT_accepted_v1.zip

## Base references

process_baseline_filename: P2C_Master_Execution_Architecture_Blueprint_Codex_v2.zip
process_baseline_sha: 094632983a72b7588252f9538998cc6a4e2d7cd26ed3f63b6b259d7ade66e175
f1_capsule_sha: 3455aafd8546accbd00501bf0320e0c17d4faee0b28ce292d595213b580d3cf8
result_audit_sha: ef878af5a17504f271eb1418accb22aed0002ad707505319096287eecfdb35e9

## Files

| File | Status | Include reason | Future location |
|---|---|---|---|
| 00_README_FIRST.md | NEW | Entry point and boundary labels. | Baseline rollup. |
| 01_CURRENT_TRUTH_ROLLUP.md | NEW | Current accepted truth and standing blockers. | Baseline rollup. |
| 02_ACCEPTED_FLOORS_CHAIN.md | NEW | Folds in Claude C-1 accepted-floor chain. | Baseline rollup. |
| 03_PINNED_INVARIANTS.md | NEW | Folds in Claude C-1 pinned invariants. | Baseline rollup. |
| 04_ARTIFACT_REGISTER.md | NEW | Key artifact names, statuses, and SHAs. | Baseline rollup. |
| 05_BOUNDARIES_AND_SOURCE_POINTERS.md | NEW | Open blockers and M8A source pointer. | Baseline rollup. |
| 06_LICH_AND_P2L_SCOPE.md | NEW | Lich and P2L lines requested by Claude C-1. | Baseline rollup. |
| 07_PROCEDURAL_INCIDENTS.md | NEW | Chain-of-custody incidents. | Baseline rollup. |
| 08_PROCESS_RULES_SUMMARY.md | NEW | Compact workflow rules. | Baseline rollup. |
| 09_NEXT_ACTIONS.md | NEW | Safe next branches. | Baseline rollup. |
| PACKAGE_MANIFEST.md | NEW | Package metadata. | Baseline rollup. |
| SHA256SUMS.txt | GENERATED | Integrity verification. | Baseline rollup. |
