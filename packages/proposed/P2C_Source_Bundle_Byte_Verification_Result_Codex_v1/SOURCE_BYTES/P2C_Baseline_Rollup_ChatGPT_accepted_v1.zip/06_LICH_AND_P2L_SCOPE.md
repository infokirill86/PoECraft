# Lich and P2L Scope Lines

## Lich policy status

Lich guarantee-one remains PROJECT_POLICY and current project-model policy, not server truth.

`lich_tag_constraint` remains canonical for the project model.

Lich priority notes must not be promoted to server-truth status without a dedicated source/provenance and mechanics gate.

Any future Lich floor requires explicit PD-013 prerequisite handling before execution.

## P2L substrate status

P2L substrate status: RC1.1 ratified low and medium-risk process/tooling only.

This means P2L substrate work may support process, tooling, packaging, and low-risk scaffolding where already accepted, but must not silently expand P2C gameplay mechanics, numeric release, source/provenance closure, or server-truth claims.
