# Next Actions

## Default recommended next step

Use this baseline rollup as the current handoff baseline for all further P2C work.

## Option A — Release-excerpt gate

Only choose this if the user explicitly wants selected numeric values shown.

Required before any values are shown:

- create a separate release-excerpt package;
- include full boundary labels adjacent to every released unit;
- include mode identity and normalization context;
- do not reframe as server-truth probability;
- get Claude review before displaying values.

## Option B — Continue implementation floors

If continuing implementation, start with a floor blueprint and a pinned DELTA.

Do not expand into advanced mechanics, optimizer, economics, or EV without separate gates.

## Option C — Source/provenance cleanup

If reducing blockers is preferred, open a source/provenance cleanup floor referencing the M8A matrix and blocker rows D-001 through D-008.

## Option D — Full reproducibility bundle

Create only if a major archival handoff is needed. It may reference this rollup, the accepted artifacts, and the quarantined result package, but should keep public numeric release rules intact.
