# Process Rules Summary

## Package workflow

- Plan large enough to understand the floor.
- Implement in medium-sized waves.
- Audit focused DELTAs.
- Merge only accepted outputs.
- Use full reproducibility bundles only at accepted-floor boundaries or explicit archival moments.

## DELTA pinning

Every DELTA must include:

- base baseline filename;
- base baseline SHA;
- base baseline status;
- prior delta chain when stacked;
- deterministic tree reference when available.

Unpinned DELTAs are not acceptable for audit.

## Acceptance authority

Only ChatGPT synthesis plus user approval may update accepted project truth or close a milestone.

Codex, Claude, a manifest, a dashboard, or a generated report may not self-accept project truth.

## Wave audit rule

Wave mode may batch intermediate work, but no wave output becomes accepted without a Claude audit of the final DELTA. Wave mode never lowers validation requirements.

## Package size discipline

Ordinary DELTA target: under 500 KB.

Packages above 1 MB require a size-budget report.

Packages around 12 MB or larger are allowed only for explicit full-reproducibility or source-history purposes, not ordinary review.
