# Artifact Register Wording Fix

## Issue

`P2C_Baseline_Rollup_Superseding_ChatGPT_accepted_v2.zip` used `FOLDED INTO THIS ROLLUP` wording for prior deltas where some status and decisions were consolidated, but some full invariant payload remained referenced through SHA-pinned artifacts rather than literally inlined.

## Corrected interpretation

For future references, read these prior artifacts as follows:

| Artifact | Prior wording | Corrected status wording |
|---|---|---|
| `P2C_Baseline_Rollup_Delta_ChatGPT_accepted_v1_1.zip` | `FOLDED INTO THIS ROLLUP` | `STATUS CONSOLIDATED; invariant payload carried forward by this v2.1 delta; original artifact remains SHA-pinned` |
| `P2C_Current_Truth_Rollup_Delta_M8C4_ChatGPT_accepted_v1.zip` | `FOLDED INTO THIS ROLLUP` | `STATUS CONSOLIDATED; detailed source artifact remains SHA-pinned; current truth carried by superseding baseline plus this v2.1 delta` |

## Practical effect

The superseding baseline v2 remains the preferred handoff reference.

This v2.1 DELTA supplies the missing standalone invariant and pointer payload so the preferred handoff surface is now bootstrappable without overstating what was already inlined in v2.

## Lineage notes

Some artifact pins remain ChatGPT/User lineage records rather than Claude-verified bytes. They must remain honestly labeled as such when used in future manifests.
