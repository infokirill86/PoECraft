# Changelog

Base: `P2C_Baseline_Rollup_Superseding_ChatGPT_accepted_v2.zip`
Base SHA256: `b34afa9a1a78ba76b29ab1c95e2af799fee65b3e11a3d2d34b9967559aad0294`

## Added

- `02_PINNED_INVARIANTS_AND_POINTERS.md`
  - Adds full source and semantic fingerprint values.
  - Adds M4 compact hash, M4 full hash, M4 CANDIDATE_DIGEST, initial-state hash, static index, and legacy retained fingerprint.
  - Adds P2L scope carry-forward line.
  - Adds M8A source/provenance blocker matrix pointer `D-001` through `D-008`.
  - Adds procedural incidents standing rule.

- `03_REGISTER_WORDING_FIX.md`
  - Clarifies prior `FOLDED INTO THIS ROLLUP` wording.
  - Distinguishes status consolidation from literal payload inlining.

## Non-actions

- No code changes.
- No feature implementation.
- No new floor opened.
- No probability values released.
- No quarantined artifacts included.
- No source/provenance closure.
- No MML closure.
- No PD-013 closure.
- No server-truth probability claim.
