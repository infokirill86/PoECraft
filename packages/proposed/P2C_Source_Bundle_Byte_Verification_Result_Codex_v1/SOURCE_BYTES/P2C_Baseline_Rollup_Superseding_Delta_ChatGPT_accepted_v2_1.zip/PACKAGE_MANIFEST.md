# Package Manifest

Package: `P2C_Baseline_Rollup_Superseding_Delta_ChatGPT_accepted_v2_1.zip`
Package type: `PINNED_DELTA / SUPERSEDING_BASELINE_ROLLUP_PATCH`
Status: `accepted`

Base baseline filename: `P2C_Baseline_Rollup_Superseding_ChatGPT_accepted_v2.zip`
Base baseline SHA256: `b34afa9a1a78ba76b29ab1c95e2af799fee65b3e11a3d2d34b9967559aad0294`
Base baseline status: `accepted preferred current handoff baseline, Claude GO WITH CHANGES`
Prior delta chain: `none`

## Purpose

Fold Claude spot-audit C-1 and C-2 into the superseding baseline surface without reissuing the full baseline package.

## File inventory

| File | Status | Include reason | Recommended future location |
|---|---|---|---|
| `00_README_FIRST.md` | NEW | Explains this compact v2.1 delta. | Baseline delta package. |
| `01_STANDALONE_COMPLETENESS_PATCH.md` | NEW | Summarizes C-1/C-2 scope and non-actions. | Baseline delta package. |
| `02_PINNED_INVARIANTS_AND_POINTERS.md` | NEW | Carries missing standalone invariants, P2L line, source pointer, and procedural rule. | Next superseding baseline rollup. |
| `03_REGISTER_WORDING_FIX.md` | NEW | Fixes `FOLDED INTO THIS ROLLUP` interpretation. | Next superseding baseline rollup. |
| `CHANGELOG.md` | NEW | Records exact changes from v2. | Baseline delta package. |
| `PACKAGE_MANIFEST.md` | NEW | Package inventory and base pinning. | Baseline delta package. |
| `SHA256SUMS.txt` | GENERATED | Integrity verification. | Baseline delta package. |

## Boundary status

- Public broad release: NOT AUTHORIZED.
- Public numeric release beyond separately audited excerpts: NOT AUTHORIZED.
- Source/provenance blockers: OPEN.
- MML: PROJECT-MODEL ASSUMPTION ONLY.
- PD-013: OPEN.
- Server-truth probability claims: FORBIDDEN.
- Optimizer/economics/EV/expected-attempts/advice: NOT OPENED.

## Lineage-note status

The following should remain honestly labeled in future artifacts when applicable:

- `P2C_Baseline_Rollup_Delta_ChatGPT_accepted_v1_1.zip` SHA `20ebfe60f492168423c959dcfe684a3be70863bc6255b10a326ac03408600b42` is a ChatGPT/User lineage pin unless separately Claude-verified.
- `P2C_Current_Truth_Rollup_Delta_M8C4_ChatGPT_accepted_v1.zip` SHA `345c27ffffbe1f65bc78dab9d745c46ba833cac74ce35fe168bfced1cf3ed65a` is a ChatGPT/User lineage pin unless separately Claude-verified.
