# P2C Baseline Rollup Superseding Delta - ChatGPT accepted v2.1

Package type: `PINNED_DELTA / SUPERSEDING_BASELINE_ROLLUP_PATCH`

Status: accepted low-risk baseline-rollup delta after user `go` and ChatGPT synthesis.

Base baseline:

```text
P2C_Baseline_Rollup_Superseding_ChatGPT_accepted_v2.zip
SHA256: b34afa9a1a78ba76b29ab1c95e2af799fee65b3e11a3d2d34b9967559aad0294
```

Purpose:

This compact DELTA folds Claude spot-audit findings C-1 and C-2 into the superseding baseline surface without reissuing the full baseline package.

It adds:

1. Standalone pinned engine invariants and navigation pointers.
2. P2L scope carry-forward.
3. M8A source/provenance blocker-matrix pointer.
4. Procedural chain-of-custody standing rule.
5. A wording fix for prior `FOLDED INTO THIS ROLLUP` phrasing.

This package releases no probability values and includes no quarantined artifacts.

Public broad release remains NOT authorized. Source/provenance blockers remain open. MML remains project-model assumption only. PD-013 remains open.
