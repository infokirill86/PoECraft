# Pinned Invariants and Navigation Pointers

These values and pointers are carried forward so the superseding baseline remains bootstrappable without needing the full prior conversation.

## Engine and data invariants

| Name | Value | Status | Use |
|---|---|---|---|
| accepted source-data fingerprint | `1577c05b13f02611d08111a5db7a765de61a30793c1b864840d6e5831efbf05b` | ACCEPTED carry-forward | Real-data snapshot continuity check. |
| post-M7h semantic fingerprint | `b268eb88389461d6cf5a435050278caaf0f36b3acfbf74e4bf1d29f9d2e14c3a` | ACCEPTED carry-forward | Static semantic continuity check. |
| initial-state hash | `6f50bd3a650f615821750eef8b8de8f1b18d63b8e024dda1091abb4009806b32` | ACCEPTED carry-forward | Fractured Crit Quarterstaff initial-state identity. |
| M4 compact hash | `a155c13eda6b979292bd03d339ac0cc5f49645aa3bbf008b7c054dcc4f24e294` | ACCEPTED carry-forward | Compact M4 ledger continuity. |
| M4 full hash | `a55fa602b408e788baf7908e9cfada01ec5e1f6d5bac80790f866cb74330910e` | ACCEPTED carry-forward | Full M4 ledger continuity. |
| M4 CANDIDATE_DIGEST | `8d289dcf2a5ad4b1d489ac92a097b95bb66374770816b52eb0285979a59523b5` | ACCEPTED carry-forward | `validate_m4` output field supplied by Claude rollup spot audit as reproduced execution evidence. |
| static index | `188` | ACCEPTED carry-forward | Static index continuity check. |
| old foundation fingerprint retained | `82fe2cfd20cee78f794c6b2df9dc2afd20b9709e17c83c309bdfee1a5fd8547f` | LEGACY RETAINED | Historical carry-forward reference. |

## Invariant handling rule

Any future numeric, real-data, static-data, or mapping DELTA that changes one of these values must STOP unless the change is explicitly acknowledged, justified, and audited.

## P2L scope carry-forward

P2L substrate status: `RC1.1 ratified low and medium-risk process/tooling only`.

This means P2L substrate work may support process, tooling, packaging, and low-risk scaffolding where already accepted, but must not silently expand P2C gameplay mechanics, numeric release, source/provenance closure, or server-truth claims.

## Source/provenance navigation pointer

Detailed source/provenance status remains in the M8A provenance manifest / coverage matrix, including blocker rows `D-001` through `D-008`.

Carry-forward notes:

- Missing PoE2DB / Craft of Exile original artifacts remain source/provenance concerns where applicable.
- Fractured-Crit tier/source dependency remains open.
- Agreement between data sources is corroboration only, not independent server-truth proof.
- Cross-version mismatch remains a stop trigger.

## Procedural incidents standing rule

No verification claim is accepted unless the verifying agent had the actual artifact bytes and a pinned SHA or deterministic reconstruction path.

This rule carries forward from the procedural incidents register and applies to all future ChatGPT, Codex, Claude, and user-mediated review loops.
